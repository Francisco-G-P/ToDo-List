package com.example.demo.repository;

import com.example.demo.model.Todo;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Repository // Marca esta clase como un componente gestionado por Spring
public class InMemoryTodoRepository {

    private final Map<Long, Todo> todoMap = new HashMap<>();
    private long idCounter = 1; // Para generar IDs únicos automáticamente

    // Guardar una nueva tarea
    public Todo save(Todo todo) {
        if (todo.getId() == null) {
            todo.setId(idCounter++);
        }
        todoMap.put(todo.getId(), todo);
        return todo;
    }

    // Obtener una tarea por ID
    public Optional<Todo> findById(Long id) {
        return Optional.ofNullable(todoMap.get(id));
    }

    // Obtener todas las tareas
    public List<Todo> findAll() {
        return new ArrayList<>(todoMap.values());
    }

    // Eliminar una tarea por ID
    public boolean deleteById(Long id) {
        return todoMap.remove(id) != null;
    }

    // Filtrar tareas con múltiples condiciones
    public List<Todo> findWithFilters(Optional<String> text, Optional<String> priority, Optional<Boolean> doneUndone) {
        return todoMap.values().stream()
                .filter(todo -> text.map(t -> todo.getText().toLowerCase().contains(t.toLowerCase())).orElse(true))
                .filter(todo -> priority.map(p -> todo.getPriority().equalsIgnoreCase(p)).orElse(true))
                .filter(todo -> doneUndone.map(d -> todo.isDoneUndone() == d).orElse(true))
                .collect(Collectors.toList());
    }
}
