package com.example.demo.controller;

import com.example.demo.model.Todo;
import com.example.demo.repository.InMemoryTodoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/todos")
public class TodoController {

    @Autowired
    private InMemoryTodoRepository todoRepository;

    // Endpoint para listar tareas con filtros y paginación
    @GetMapping
    public List<Todo> getTodos(
            @RequestParam Optional<String> text,
            @RequestParam Optional<String> priority,
            @RequestParam Optional<Boolean> doneUndone,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        // Filtrar tareas usando el repositorio
        List<Todo> filteredTodos = todoRepository.findWithFilters(text, priority, doneUndone);

        // Implementar la lógica de paginación
        int fromIndex = (page - 1) * size;
        int toIndex = Math.min(fromIndex + size, filteredTodos.size());

        if (fromIndex > filteredTodos.size()) {
            return List.of(); // Retornar lista vacía si la página está fuera del rango
        }

        return filteredTodos.subList(fromIndex, toIndex);
    }
}
