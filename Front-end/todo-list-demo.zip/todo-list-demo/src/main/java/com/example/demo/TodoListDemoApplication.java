package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoListDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoListDemoApplication.class, args);
	}

}
