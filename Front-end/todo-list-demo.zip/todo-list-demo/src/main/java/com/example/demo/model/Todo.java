package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity // Esto indica que la clase puede ser persistida en una base de datos en el
        // futuro
public class Todo {

    @Id // Indica que este atributo es la clave primaria
    @GeneratedValue(strategy = GenerationType.AUTO) // Genera automáticamente un valor único para el ID
    private Long id;

    @Column(nullable = false, length = 120) // El texto no puede ser nulo y tiene un límite de 120 caracteres
    private String text;

    @Column(nullable = false) // Este atributo es obligatorio
    private String priority; // Puede ser "low", "medium" o "high"

    @Column(nullable = false)
    private boolean doneUndone; // true = completada, false = sin completar

    @Column(nullable = false)
    private LocalDate creationDate; // Fecha de creación, no puede ser nula

    private LocalDate dueDate; // Fecha opcional de entrega

    private LocalDate doneDate; // Fecha opcional de finalización

    // Constructor vacío (requerido por JPA)
    public Todo() {
    }

    // Constructor completo
    public Todo(String text, String priority, boolean doneUndone, LocalDate creationDate, LocalDate dueDate,
            LocalDate doneDate) {
        this.text = text;
        this.priority = priority;
        this.doneUndone = doneUndone;
        this.creationDate = creationDate;
        this.dueDate = dueDate;
        this.doneDate = doneDate;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        if (text.length() > 120) {
            throw new IllegalArgumentException("Text cannot exceed 120 characters");
        }
        this.text = text;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        if (!priority.equals("low") && !priority.equals("medium") && !priority.equals("high")) {
            throw new IllegalArgumentException("Priority must be 'low', 'medium', or 'high'");
        }
        this.priority = priority;
    }

    public boolean isDoneUndone() {
        return doneUndone;
    }

    public void setDoneUndone(boolean doneUndone) {
        this.doneUndone = doneUndone;
    }

    public LocalDate getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDate creationDate) {
        this.creationDate = creationDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getDoneDate() {
        return doneDate;
    }

    public void setDoneDate(LocalDate doneDate) {
        this.doneDate = doneDate;
    }

    @Override
    public String toString() {
        return "Todo{" +
                "id=" + id +
                ", text='" + text + '\'' +
                ", priority='" + priority + '\'' +
                ", doneUndone=" + doneUndone +
                ", creationDate=" + creationDate +
                ", dueDate=" + dueDate +
                ", doneDate=" + doneDate +
                '}';
    }
}
